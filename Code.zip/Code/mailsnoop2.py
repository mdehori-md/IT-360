import win32com.client
import os
import re
#open outlook and points to API I think?
outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

#email is superpositioned until now
schrodingers_mail = input("Would you like to analyze recieved or sent emails?")

#prompt for specific name
name = input("Is there a specific name (Y/N):")
if name == "y":
        suspect = input("Please enter the name:")
else:
    suspect = False

#parse the mails state
#6 is inbox 5 is sent
if schrodingers_mail == "recieved":
    inbox = outlook.GetDefaultFolder(6)
elif schrodingers_mail == "sent":
    inbox = outlook.GetDefaultFolder(5)
else:
    inbox = None

if inbox:
    messages = inbox.Items
else:
    messages = []  # Ensure messages is defined when inbox is None

# Define the folder where the emails will be saved
save_path = "C:\Emails"  
if not os.path.exists(save_path):
    os.makedirs(save_path)

# New function to save an email
def save_email(i, message):
    subject = message.Subject if message.Subject else "No Subject"
    filename = f"{(subject)}.txt"
    full_path = os.path.join(save_path, filename)
    message.SaveAs(full_path)
    print(f"Saved email: {full_path}")

# Loop through all emails and save them as txt (might change later)
for i, message in enumerate(messages):
    try:
        if suspect:
            if suspect == message.SenderName:
                save_email(i, message)
        else:
            save_email(i, message)
    except Exception as e:
        print("Error")
