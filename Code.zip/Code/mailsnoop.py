import time
import subprocess
import keyboard
import webbrowser
#def var file_path/file_name hardcoded for testing
#file_path=input("Please enter the absolute file path for the folders to be stored:")
#file_name=input("Please enter what you would like the file to be called")
file_name="test"
#open outlook in def web
webbrowser.open("https://outlook.office.com/mail/")
#below is the file saving and opening
time.sleep(2)
keyboard.press_and_release('enter')
time.sleep(2)
keyboard.press_and_release('ctrl + S')
time.sleep(2)
keyboard.write(file_name)
time.sleep(2)
keyboard.press_and_release('enter')
time.sleep(5)
#open download
file_path = r"C:\Users\joeym\Downloads\test.html"
with open(file_path, "r", encoding="utf-8") as f:
    print(f.read())
