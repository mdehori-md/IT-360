import win32com.client
import os
import re
import hashlib

#open outlook and points to API I think?
outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

#email is superpositioned until now
schrodingers_mail = input("Would you like to analyze recieved or sent emails?")

#prompt for specific name
name = input("Is there a specific name (Y/N):")
if name == "y":
        suspect = input("Please enter the name:")
else:
    suspect = False

#parse the mails state
#6 is inbox 5 is sent
if schrodingers_mail == "recieved":
    inbox = outlook.GetDefaultFolder(6)
elif schrodingers_mail == "sent":
    inbox = outlook.GetDefaultFolder(5)
else:
    inbox = None

if inbox:
    messages = inbox.Items
else:
    messages = []  

# Define the folder where the emails will be saved
save_path = "C:\Emails"  
if not os.path.exists(save_path):
    os.makedirs(save_path)

# Save below
def save_email(i, message):
    subject = message.Subject if message.Subject else "No Subject"
    filename = f"{subject}.txt"
    full_path = os.path.join(save_path, filename)

    try:
        with open(full_path, "w", encoding="utf-8") as file:
            file.write(message.Body)  
        print(f"Saved email: {full_path}")
        return full_path
    except Exception as e:
        print(f"Error saving email: {e}")
        return None



#hashing starts below 
def compute_file_hash(full_path, algorithm='sha256'):
    hash_func = hashlib.new(algorithm)
    
    with open(full_path, 'rb') as file:
        while chunk := file.read(8192):  #8192 bytes
            hash_func.update(chunk)
    
    return hash_func.hexdigest()

#applies hash to each email
def main():
    algorithm = input("Enter the hash algorithm (e.g., md5, sha1, sha256): ")
    for i, message in enumerate(messages):
        try:
            if suspect:
                if suspect == message.SenderName:
                    file_path = save_email(i, message)
                    file_hash = compute_file_hash(file_path, algorithm)
                    print(f"The hash of the file {file_path} is: {file_hash}")
            else:
                file_path = save_email(i, message)
                file_hash = compute_file_hash(file_path, algorithm)
                print(f"The hash of the file {file_path} is: {file_hash}")
        except Exception as e:
            print("Error")

if __name__ == "__main__":
    main()
