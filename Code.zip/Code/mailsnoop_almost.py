import win32com.client
import os
import re
import hashlib

# Open outlook and points to API
outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
sent = 0 #Initalize sent variable 0=it wont run run() 1=it will run run()

startup = input("1: Start new case file \n2: Open existing case\n3: Keyword search\nSelect option (1/2/3): ")
if startup =="1":
    # save_path = input("Please enter the file path for saving the files:") hardcoded for testing UNDO\\\\\\\\\\\
    sent = 1
elif startup == "2":
    filepath = input ("Please enter filepath: ")
    os.startfile(filepath)
elif startup == "3":
    #keyword search is below
    #filepath = input ("Please enter filepath: ") prompts for filepath hardcoded for now UNDO\\\\\\\\\
    filepath = "c:\emails"
    keyword = input("Please enter the keyword: ")
    directory = os.listdir(filepath)
    found_files = [] #start array
    
    for fname in directory:
        if os.path.isfile(os.path.join(filepath, fname)):
            with open(os.path.join(filepath, fname), 'r', encoding="utf-8", errors="ignore") as f:
                if keyword in f.read():
                    found_files.append(fname) #store filenames in array
                    print (found_files)
            
    search_open = input("Would you like to open the case folder?")
    if search_open.lower() == "y":
        for file in found_files:
            os.startfile(os.path.join(filepath, file))

#Option 1 below
def run():
    global sent
    while sent == 1:
        # Email is superpositioned until now
        schrodingers_mail = input("Would you like to analyze received or sent emails?")

        # Prompt for specific name
        name = input("Is there a specific name (Y/N):")
        if name.lower() == "y":
            suspect = input("Please enter the name:")
        else:
            suspect = False

        # Parse the mails state
        # 6 is inbox, 5 is sent
        if schrodingers_mail.lower() == "received":
            inbox = outlook.GetDefaultFolder(6)
        elif schrodingers_mail.lower() == "sent":
            inbox = outlook.GetDefaultFolder(5)
        else:
            inbox = None

        if inbox:
            messages = inbox.Items
        else:
            messages = []

        # Define the folder where the emails will be saved
        save_path = "C:\\Emails"
        if not os.path.exists(save_path):
            os.makedirs(save_path)

        # Removes invalid characters
        def sanitize_filename(filename):
            return re.sub(r'[\\/*?"<>|]', '_', filename)

        # Save below
        def save_email(i, message):
            subject = message.Subject if message.Subject else "No Subject"
            filename = sanitize_filename(f"{subject}.txt")
            full_path = os.path.join(save_path, filename)

            try:
                with open(full_path, "w", encoding="utf-8") as file:
                    file.write(message.Body)
                print(f"Saved email: {full_path}")
                return full_path, filename
            except Exception as e:
                print(f"Error saving email: {e}")
                return None, None

        # hashing starts below
        def compute_file_hash(full_path, algorithm='sha256'):
            hash_func = hashlib.new(algorithm)

            with open(full_path, 'rb') as file:
                while chunk := file.read(8192):  # 8192 bytes
                    hash_func.update(chunk)

            return hash_func.hexdigest()

        # applies hash to each email
        def main():
            algorithm = input("Enter the hash algorithm (e.g., md5, sha1, sha256): ")
            for i, message in enumerate(messages):
                try:
                    if suspect:
                        if suspect == message.SenderName:
                            file_path, filename = save_email(i, message)
                            file_hash = compute_file_hash(file_path, algorithm)
                            save_hash(file_hash, filename, algorithm)
                    else:
                        file_path, filename = save_email(i, message)
                        file_hash = compute_file_hash(file_path, algorithm)
                        save_hash(file_hash, filename, algorithm)
                except Exception as e:
                    print(f"Error: {e}")

        # Puts all hashes into hash_master_list file
        def save_hash(file_hash, filename, algorithm):
            hash_name = "hash_master_list.txt"
            hash_path = os.path.join(save_path, hash_name)
            with open(hash_path, "a") as f:
                f.write(f"{algorithm} {filename}: {file_hash}\n")

        main()

        # Prompts to open case folder
        convenience = input("Would you like to open the case folder?")
        if convenience.lower() == "y":
            os.startfile(save_path)

        # Ask to rerun
        rerun = input("Would you like to rerun the program?")
        if rerun.lower() == "y":
            sent = 1
        else:
            sent = 0
        

if __name__ == "__main__":
    run()
