import win32com.client
import os
import re
#open outlook and points to API I think?
outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

#email is superpositioned until now
schrodingers_mail = input("Would you like to analyze recieved or sent emails?")

#prompt for specific name
name = input("Is there a specific name (Y/N):")
if name =="Y":
        suspect = input("Please enter the name:")
else:
    suspect = False
#parse the mails state
#6 is inbox 5 is sent
if schrodingers_mail == "recieved":
    inbox = outlook.GetDefaultFolder(6)
elif schrodingers_mail == "sent":
    inbox = outlook.GetDefaultFolder(5)
if inbox:
    messages = inbox.Items

# Define the folder where the emails will be saved
save_path = "C:\Emails"  
if not os.path.exists(save_path):
    os.makedirs(save_path)

# Loop through all emails and save them as txt (might change later)
for i, message in enumerate(messages):
    try:
        # set the filename to the subject line
        subject = message.Subject if message.Subject else "No Subject"
        filename = f"{i+1}_{(subject)}.txt"
        full_path = os.path.join(save_path, filename)
        
        # saves email 
        message.SaveAs(full_path) #this saves the email below is a formality
        print(f"Saved email: {full_path}")
    except Exception as e:
        print("Error")
