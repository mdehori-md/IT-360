import win32com.client
import os
import re

# Open Outlook
outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

# List available Outlook accounts
print("Available Outlook accounts:")
for account in outlook.Folders:
    print(" -", account.Name)

# Prompt the user for which account to analyze
account_choice = input("Enter the name of the Outlook account to analyze: ")
try:
    account_folder = outlook.Folders[account_choice]
except Exception as e:
    print("bad name")
    exit()

# mail is superpositioned until now
mail_type = input("Would you like to analyze received or sent emails? ").lower()

# ask for susepcts name
name_filter = input("Is there a specific name (Y/N): ").upper()
if name_filter == "Y":
    suspect = input("Please enter the name: ")
else:
    suspect = None

# pciks folder
if mail_type == "received":
    try:
        mail_folder = account_folder.Folders["Inbox"]
    except Exception as e:
        print("Could not find the Inbox folder in the selected account. Exiting.")
        exit()
elif mail_type == "sent":
    try:
        mail_folder = account_folder.Folders["Sent Items"]
    except Exception as e:
        print("Could not find the Sent Items folder in the selected account. Exiting.")
        exit()
else:
    print("Invalid mail type selected. Exiting.")
    exit()

messages = mail_folder.Items

# Define the folder where the emails will be saved
save_path = r"C:\Emails"  # Use a raw string for Windows paths
if not os.path.exists(save_path):
    os.makedirs(save_path)

# Loop through all emails and save them as .txt files
for i, message in enumerate(messages):
    try:
        # If a suspect name is provided, you might want to filter emails here.
        # For example, you can check if the suspect's name is in the sender or subject.
        if suspect:
            if suspect.lower() not in (message.SenderName.lower() if message.SenderName else "") and \
               suspect.lower() not in (message.Subject.lower() if message.Subject else ""):
                continue  # Skip this email if it doesn't match the suspect name

        subject = message.Subject if message.Subject else "No Subject"
        # Remove any characters from the subject that are invalid for file names
        subject = re.sub(r'[\\/*?:"<>|]', "", subject)
        filename = f"{i+1}_{subject}.txt"
        full_path = os.path.join(save_path, filename)
        
        # Save the email
        message.SaveAs(full_path)
        print(f"Saved email: {full_path}")
    except Exception as e:
        print("Error saving email:", e)
