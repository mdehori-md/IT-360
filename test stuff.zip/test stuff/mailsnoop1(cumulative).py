import win32com.client
import os
import re

#open outlook and points to API I think?
outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")


def cumulative(outlook, folder):
    inbox = outlook.GetDefaultFolder(folder)
    messages = inbox.Items
    save_emails(messages, save_path)
                
# Define the folder where the emails will be saved
save_path = "C:\Emails"  
if not os.path.exists(save_path):
    os.makedirs(save_path)                
def save_emails(messages, save_path):
        for i, message in enumerate(messages):
                try:
            # Set the filename to the subject line
                    subject = message.Subject if message.Subject else "No Subject"
                    safe_subject = re.sub(r'[<>:"/\\|?*]', '_', subject)  # Replace invalid filename characters
                    filename = f"{safe_subject}_email_{i+1}.txt"
                    full_path = os.path.join(save_path, filename)
            
            # Save email
                    message.SaveAs(full_path)
                    print(f"Saved email: {full_path}")
                except Exception as e:
                    print(f"Error: {e}")
#email is superpositioned until now
schrodingers_mail = input("Would you like to analyze recieved, sent, or deleted emails?")

#prompt for specific name
name = input("Is there a specific name (Y/N):")
if name =="Y":
        suspect = input("Please enter the name:")
else:
    suspect = False
#parse the mails state
#6 is inbox 5 is sent 3 is deleted
if schrodingers_mail == "recieved":
    cumulative(outlook, 6)
elif schrodingers_mail == "sent":
    cumulative(outlook, 5)
elif schrodingers_mail == "deleted":
    cumulative(outlook, 3)
elif schrodingers_mail == "all":
    cumulative(outlook, 3,5,6)
   




